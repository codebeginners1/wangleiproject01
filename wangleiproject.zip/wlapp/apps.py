# wlapp应用的配置
from django.apps import AppConfig


class WlappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "wlapp"
